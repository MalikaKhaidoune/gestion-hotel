﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionHotel
{
    internal class Reservation
    {
        // Nom du client effectuant la réservation
        private string _nomClient;
        public string NomClient
        {
            get { return _nomClient; }
            set { _nomClient = value; }
        }
        // Prénom du client effectuant la réservation
        private string _prenomClient;
        public string PrenomClient
        {
            get { return _prenomClient; }
            set { _prenomClient = value; }
        }
        // Numéro de la chambre réservée
        private int _numeroChambre; 
        public int NumeroChambre
        {
            get { return _numeroChambre; }
            set { _numeroChambre = value; }
        }
        // Date d'arrivée pour la réservation
        private DateTime _dateArrivee; 
        public DateTime DateArrivee
        {
            get { return _dateArrivee; }
            set { _dateArrivee = value; }
        }
        // Date de départ pour la réservation
        private DateTime _dateDepart; 
        public DateTime DateDepart
        {
            get { return _dateDepart; }
            set { _dateDepart = value; }
        }
        // Nombre d'adultes pour la réservation
        private int _nombreAdultes; 
        public int NombreAdultes
        {
            get { return _nombreAdultes; }
            set { _nombreAdultes = value; }
        }
        // Nombre d'enfants pour la réservation
        private int _nombreEnfants; 
        public int NombreEnfants
        {
            get { return _nombreEnfants; }
            set { _nombreEnfants = value; }
        }
        // Indique si le petit déjeuner est inclus dans la réservation
        private bool _petitDejeunerInclus; 
        public bool PetitDejeunerInclus
        {
            get { return _petitDejeunerInclus; }
            set { _petitDejeunerInclus = value; }
        }
    }
}
