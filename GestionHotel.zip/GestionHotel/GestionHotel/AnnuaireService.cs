﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionHotel
{
    internal class AnnuaireService
    {
        private List<Client> listeClients = new List<Client>();

        /// <summary>
        /// Initialisation d'une liste de personnes
        /// </summary>
        /// <returns>Une liste de personnes préinitialisées</returns>
        public void InitListeClients()
        {
            Client cli1 = new Client();
            cli1.Sexe = "Masculin";
            cli1.Nom = "Dupond";
            cli1.Prenom = "Paul";
            cli1.Ville = "Paris";
            cli1.CodePostal = 75015;
            cli1.DateNaissance = new DateTime(1984, 1, 10);

            listeClients.Add(cli1);

            Client cli2 = new Client();
            cli2.Sexe = "Féminin";
            cli2.Nom = "Martin";
            cli2.Prenom = "Amandine";
            cli2.Ville = "Lyon";
            cli2.CodePostal = 69002;
            cli2.DateNaissance = new DateTime(1988, 10, 5);

            listeClients.Add(cli2);

            Client cli3 = new Client();
            cli3.Sexe = "Féminin";
            cli3.Nom = "Deau";
            cli3.Prenom = "Marie";
            cli3.Ville = "Lyon";
            cli3.CodePostal = 69003;
            cli3.DateNaissance = new DateTime(1960, 3, 8);

            listeClients.Add(cli3);


        }

        /// <summary>
        /// Renvoie la liste des personnes présentes dans l'annuaire
        /// </summary>
        /// <returns>msmsms
        /// </returns>
        public List<Client> GetListeClients()
        {
            return listeClients;
        }

        /// <summary>
        /// Création en base de données de la personne passée en paramètres
        /// </summary>
        /// <param name="client"></param>
        public void CreationClients(Client client)
        {
            listeClients.Add(client);
        }

        /// <summary>
        /// Suppression en base de données de la personne passée en paramètres
        /// </summary>
        /// <param name="personne"></param>
        public void SuppressionClients(Client client)
        {
            listeClients.Remove(client);
        }

        /// <summary>
        /// Recherche et renvoie les personnes de l'annuaire filtrées par ville
        /// </summary>
        /// <param name="ville"></param>
        /// <returns></returns>
        public List<Client> RechercheClientsParNom(string nom)
        {
            List<Client> listeClients = null;

            //Recherche des clients via une requête LinQ
            var requeteClients = from elements in GetListeClients()
                                   where elements.Nom == nom
                                   select elements;


            listeClients = requeteClients.ToList();
            return listeClients;
        }
    }
}
