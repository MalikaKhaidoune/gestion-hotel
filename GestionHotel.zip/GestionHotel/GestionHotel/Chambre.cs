﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionHotel
{
    internal class Chambre
    {
        // Type de chambre (simple, double, suite, etc.)
        private string _type; 
        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }
        // Numéro de la chambre
        private int _numero; 
        public int Numero
        {
            get { return _numero; }
            set { _numero = value; }
        }
        // Indique si la chambre est disponible ou non
        private bool _disponible; 
        public bool Disponible
        {
            get { return _disponible; }
            set { _disponible = value; }
        }
        // Prix de la chambre par nuit
        private double _prix; 
        public double Prix
        {
            get { return _prix; }
            set { _prix = value; }
        }
        // Indique si la chambre a été nettoyée ou non
        private bool _nettoyee; 
        public bool Nettoyee
        {
            get { return _nettoyee; }
            set { _nettoyee = value; }
        }
        // Indique si la chambre est équipée de climatisation
        private bool _climatisation; 
        public bool Climatisation
        {
            get { return _climatisation; }
            set { _climatisation = value; }
        }
        // Indique si la chambre a une vue sur la mer
        private bool _vueMer; 
        public bool VueMer
        {
            get { return _vueMer; }
            set { _vueMer = value; }
        }
        // Indique si la chambre est équipée de wifi
        private bool _wifi; 
        public bool Wifi
        {
            get { return _wifi; }
            set { _wifi = value; }
        }
    }
}
