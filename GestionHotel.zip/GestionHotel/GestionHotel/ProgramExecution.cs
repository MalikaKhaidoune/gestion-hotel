﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionHotel
{
    internal class ProgramExecution
    {
        private AnnuaireService service = new AnnuaireService();

        /// <summary>
        /// Affichage du menu console et accès aux fonctionnalités
        /// </summary>
        public void Execution()
        {

            string reponse = null;
            service.InitListeClients();
            while (reponse != "4")
            {
                Console.WriteLine("Bienvenue dans l'application de gestion d'hotel");
                Console.WriteLine("Que voulez-vous faire?");
                Console.WriteLine("Tapez 1 puis validez pour lister les personnes présentes en base");
                Console.WriteLine("Tapez 2 puis validez pour créer une nouvelle personne");
                Console.WriteLine("Tapez 3 puis validez pour cherchez les personnes par ville");
                Console.WriteLine("Tapez 4 pour quitter");

                //Attente de la réponse de l'utilisateur
                reponse = Console.ReadLine();
                if (reponse == "1")
                {
                    //Affichage de toutes les clients

                    AfficherListeClients(service.GetListeClients());
                }
                else if (reponse == "2")
                {
                    //Création d'un objet PersonneAnnuaire à partir des données saisies
                    Client client = new Client();
                    Console.WriteLine("Civilité : ");
                    client.Civilite = Console.ReadLine();
                    Console.WriteLine("Nom : ");
                    client.Nom = Console.ReadLine();
                    Console.WriteLine("Prénom : ");
                    client.Prenom = Console.ReadLine();
                    Console.WriteLine("Ville : ");
                    client.Ville = Console.ReadLine();
                    Console.WriteLine("Code postal : ");
                    client.CodePostal = int.Parse(Console.ReadLine());
                    Console.WriteLine("Nom de la rue : ");
                    Console.WriteLine("Année de naissance : ");
                    int anneeNaissance = int.Parse(Console.ReadLine());
                    Console.WriteLine("Mois de naissance : ");
                    int moisNaissance = int.Parse(Console.ReadLine());
                    Console.WriteLine("Jour de naissance : ");
                    int jourNaissance = int.Parse(Console.ReadLine());
                    DateTime dateNaissance = new DateTime(anneeNaissance, moisNaissance, jourNaissance);
                    client.DateNaissance = dateNaissance;
                    Console.WriteLine("Numéro de téléphone : ");
                    client.NumeroTelephone = Console.ReadLine();

                    //Appel du service de création
                    service.CreationClients(client);
                    Console.WriteLine("Le client a bien été créée");
                }
                else if (reponse == "3")
                {
                    Console.WriteLine("Saisissez le nom du client : ");
                    string nom = Console.ReadLine();
                    List<Client> listeClientsTrouvees = service.RechercheClientsParNom(nom);
                    AfficherListeClients(listeClientsTrouvees);
                }
            }
        }

        /// <summary>
        /// Affiche la liste des personnes passées en paramètre
        /// </summary>
        /// <param name="listePersonnes"></param>
        private void AfficherListeClients(List<Client> listeClients)
        {
            foreach (Client client in listeClients)
            {
                Console.WriteLine(client.Nom + "  " + client.Prenom + " - né le " + client.DateNaissance.ToString());
                Console.WriteLine("Ville : " + client.Ville);
                Console.WriteLine("Civilité : " + client.Civilite);
                Console.WriteLine("Code Postal : " + client.CodePostal);
                Console.WriteLine("Téléphone : " + client.NumeroTelephone);
                Console.WriteLine("-----------------------------------------------");
            }
        }
    }
}
