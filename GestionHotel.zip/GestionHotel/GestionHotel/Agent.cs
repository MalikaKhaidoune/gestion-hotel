﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionHotel
{
    internal class Agent
    {
        private string _civilite;
        public string Civilite
        {
            get { return _civilite; }
            set { _civilite = value; }
        }

        private string _sexe;
        public string Sexe
        {
            get { return _sexe; }
            set { _sexe = value; }
        }

        private string _nom;
        public string Nom
        {
            get { return _nom; }
            set { _nom = value; }
        }

        private string _prenom;
        public string Prenom
        {
            get { return _prenom; }
            set { _prenom = value; }
        }

        private DateTime _dateNaissance;
        public DateTime DateNaissance
        {
            get { return _dateNaissance; }
            set { _dateNaissance = value; }
        }

        private string _ville;
        public string Ville
        {
            get { return _ville; }
            set { _ville = value; }
        }

        private int _codePostal;
        public int CodePostal
        {
            get { return _codePostal; }
            set { _codePostal = value; }
        }

        private string _numeroTelephone;
        public string NumeroTelephone
        {
            get { return _numeroTelephone; }
            set { _numeroTelephone = value; }
        }
    }
}
