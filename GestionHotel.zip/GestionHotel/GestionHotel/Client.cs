﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionHotel
{
    internal class Client
    {

            private string _civilite;
            public string Civilite
            {
                get { return _civilite; }
                set { _civilite = value; }
            }

            //Sexe de la personne
            private string _sexe;

            public string Sexe
            {
                get { return _sexe; }
                set { _sexe = value; }
            }

            //Nom
            private string _nom;

            public string Nom
            {
                get { return _nom; }
                set { _nom = value; }
            }

            //Prénom
            private string _prenom;

            public string Prenom
            {
                get { return _prenom; }
                set { _prenom = value; }
            }

            //Date de naissance
            private DateTime _dateNaissance;

            public DateTime DateNaissance
            {
                get { return _dateNaissance; }
                set { _dateNaissance = value; }
            }

            //Ville
            private string _ville;

            public string Ville
            {
                get { return _ville; }
                set { _ville = value; }
            }

            //Code postal
            private int _codePostal;

            public int CodePostal
            {
                get { return _codePostal; }
                set { _codePostal = value; }
            }

            //Numéro tel
            private string _numeroTelephone;

            public string NumeroTelephone
            {
                get { return _numeroTelephone; }
                set { _numeroTelephone = value; }
            }
        }
    }

