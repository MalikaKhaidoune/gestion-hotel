﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Nom] NCHAR(10) NULL, 
    [Prenom] NCHAR(10) NULL, 
    [dateNaissance] DATETIME NULL, 
    [ville] NCHAR(10) NULL, 
    [codePostal] NCHAR(10) NULL, 
    [numeroTelephone] NUMERIC NULL
)
